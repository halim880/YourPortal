

<?php $__env->startSection('content'); ?>
  <div class="row mt-3">
    <div class="col-md-6">
      <div class="card">
        <div class="card-header">
          <h3>Create Service Info</h3>
        </div>
        <div class="card-body">
          <form action="<?php echo e(route('system_admin.web_settings.service_info.update', $serviceInfo)); ?>" method="POST">
            <?php echo csrf_field(); ?>
            <div class="form-group mb-3">
              <label for="title">Title </label>
              <input type="text" class="form-control" id="title" name="title" required value="<?php echo e($serviceInfo->title); ?>">
            </div>
            <div class="form-group mb-3">
              <label for="details">Details </label>
              <textarea class="form-control" name="details" id="details" cols="30" rows="10"><?php echo e($serviceInfo->details); ?></textarea>
            </div>
            <div class="form-group mb-3">
              <label for="priority">Priority </label>
              <select class="form-control" name="priority" id="">
                <option value="1" <?php if($serviceInfo->priority==1): ?> selected <?php endif; ?>>High</option>
                <option value="2" <?php if($serviceInfo->priority==2): ?> selected <?php endif; ?>>Medium</option>
                <option value="3" <?php if($serviceInfo->priority==3): ?> selected <?php endif; ?>>Low</option>
              </select>
            </div>
            <div class="d-flex my-2">
                <button type="submit" class="btn btn-primary">Save</button>
            </div>
        </form>
        </div>
      </div>
    </div>
  </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.backend.system_admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\ABDUL HALIM\Desktop\Portal\resources\views/system_admin/web_settings/service_info/edit.blade.php ENDPATH**/ ?>