

<?php $__env->startSection('content'); ?>

<div class="account-pages pt-2 pt-sm-5 pb-4 pb-sm-5">
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-xxl-4 col-lg-5">
                <div class="card">
                    <!-- Logo -->
                    <div class="card-header pt-4 pb-4 text-center bg-appColor">
                        <a href="index.html">
                            <span><img src="assets/images/logo.png" alt="" height="18"></span>
                        </a>
                    </div>

                    <div class="card-body p-4">
                        <div class="text-center">
                            <h1 class="text-success">Hello! Akash</h1>
                            <p class="text-muted mt-3">We are processing your information. A confirmation mail will be send to <b>admin@gmail.com</b></p>

                            <a class="btn btn-info mt-3" href="<?php echo e(url('/')); ?>"><i class="mdi mdi-reply"></i> Return Home</a>
                        </div>
                    </div> <!-- end card-body-->
                </div>
                <!-- end card -->
            </div> <!-- end col -->
        </div>
        <!-- end row -->
    </div>
    <!-- end container -->
</div>
<!-- end page -->

<footer class="footer footer-alt">
    2021 © <?php echo e(config('app.name')); ?>

</footer>




    
<?php $__env->stopSection(); ?>
<?php echo $__env->make('new_layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\ABDUL HALIM\Desktop\Portal\resources\views/test.blade.php ENDPATH**/ ?>