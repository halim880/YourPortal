

<?php $__env->startSection('content'); ?>

  <?php if(Session::has('message')): ?>
    <?php echo $__env->make('alerts._success', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
  <?php endif; ?>

<?php
    $xDate = $member->subscription->exp_date;
?>
  
  <div class="row mt-2">
      <div class="col-md-10">
          <div class="card">
              <div class="card-body p-4">
                <h2>Member Details</h2>
                <table class="table table-stripped">
                    <tr>
                        <th>Member Name</th>
                        <td>:</td>
                        <td><?php echo e($member->name); ?></td>
                    </tr>
                    <tr>
                        <th>Member phone</th>
                        <td>:</td>
                        <td><?php echo e($member->member_phone); ?></td>
                    </tr>
                    <tr>
                        <th>Member Email</th>
                        <td>:</td>
                        <td><?php echo e($member->member_email); ?></td>
                    </tr>
                    <tr>
                        <th>Package </th>
                        <td>:</td>
                        <td><?php echo e($member->getCurrentPackageName()); ?></td>
                    </tr>
                    <tr>
                        <th>Plan </th>
                        <td>:</td>
                        <td><?php echo e($member->getCurrentPlanName()); ?></td>
                    </tr>
                    <tr>
                        <th>Payment Status </th>
                        <td>:</td>
                        <td><?php echo e($member->getPaymentStatus()); ?></td>
                    </tr>
                    <tr>
                        <th>Expire Date </th>
                        <td>:</td>
                        <td><?php echo e($member->subscription->expireDate($xDate)); ?></td>
                    </tr>
                    <tr>
                        <th>Remaining Days </th>
                        <td>:</td>
                        <td><?php echo e($member->subscription->remainingDays($xDate)); ?></td>
                    </tr>
                </table>
                <h2>Member Admin details</h2>
                <table class="table table-stripped">
                    <tr>
                        <th>Admin Name</th>
                        <td>:</td>
                        <td><?php echo e($admin->name); ?></td>
                    </tr>
                    <tr>
                        <th>Email</th>
                        <td>:</td>
                        <td><?php echo e($admin->email); ?></td>
                    </tr>
                </table>
              </div>
          </div>
      </div>
  </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.backend.system_admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\ABDUL HALIM\Desktop\Portal\resources\views/system_admin/member/show.blade.php ENDPATH**/ ?>