
<ul class="navbar-nav ms-auto my-3 my-lg-0">
    <li class="nav-item"><a class="nav-link me-lg-3" href="#features">Support</a></li>
    <li class="nav-item"><a class="nav-link me-lg-3" href="#download">Contact</a></li>
    <li class="nav-item"><a class="nav-link me-lg-3" href="#download">F.A.Q.S</a></li>

    <?php if(auth()->guard()->guest()): ?>
        <li class="nav-item"><a style="color: white" class="nav-link btn btn-primary" href="<?php echo e(route('login')); ?>">Login</a></li>
    <?php endif; ?>

    <?php if(auth()->guard()->check()): ?>
        <li class="nav-item"><a class="nav-link me-lg-3" href="<?php echo e(route('super_admin.dashboard')); ?>">My Account</a></li>
    <?php endif; ?>
</ul><?php /**PATH C:\Users\ABDUL HALIM\Desktop\Portal\resources\views/layouts/frontend/navbar.blade.php ENDPATH**/ ?>