

<?php $__env->startSection('content'); ?>

  <?php if(Session::has('message')): ?>
    <?php echo $__env->make('alerts._success', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
  <?php endif; ?>
  
  <div class="row mt-2">
      <div class="col-md-10">
          <div class="card">
              <div class="card-body p-4">
                  <div class="d-flex justify-content-between">
                    <h4>Pricings</h4>
                    <a class="btn btn-primary p-2" href="<?php echo e(route('system_admin.pricing.create')); ?>">Add New pricing</a>
                </div>
                <table class="table">
                    <thead>
                        <th>ID</th>
                        <th>Package</th>
                        <th>Plan</th>
                        <th>Price</th>
                        <th>Action</th>
                    </thead>
                    <tbody>
                        <?php if($pricings->count()<1): ?>

                            <tr>
                                <td align="center" colspan="6">No Pricing created</td>
                            </tr>                            

                        <?php else: ?>
                            <?php $__currentLoopData = $pricings; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pricing): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($pricing->id); ?></td>
                                <td><?php echo e($pricing->getPackageName()); ?></td>
                                <td><?php echo e($pricing->getPlanName()); ?></td>
                                <td><?php echo e($pricing->currency->symbol); ?> <?php echo e($pricing->price); ?></td>
                                <td>
                                    <a href="<?php echo e(route('system_admin.pricing.edit', $pricing)); ?>" class="btn btn-primary btn-sm mt-1">Edit</a>
                                    <a href="<?php echo e(route('system_admin.pricing.destroy', $pricing)); ?>" class="btn btn-warning btn-sm mt-1">Delete</a>
                                </td>
                            </tr>                            
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php endif; ?>
                    </tbody>
                </table>
              </div>
          </div>
      </div>
  </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.backend.system_admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\ABDUL HALIM\Desktop\Portal\resources\views/system_admin/pricing/index.blade.php ENDPATH**/ ?>