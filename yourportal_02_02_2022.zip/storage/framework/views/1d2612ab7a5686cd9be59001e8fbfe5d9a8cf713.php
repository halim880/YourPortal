

<?php $__env->startSection('content'); ?>

  <?php if(Session::has('message')): ?>
    <?php echo $__env->make('alerts._success', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
  <?php endif; ?>
  
  <div class="row mt-2">
      <div class="col-md-10">
          <div class="card">
              <div class="card-body p-4">
                <h2>List of Members</h2>
                <table class="table">
                  <thead>
                      <th>Name</th>
                      <th>Subscription Type</th>
                      <th>Expire Date</th>
                      <th>Remaining Days</th>
                      <th>Action</th>
                  </thead>
                  <tbody>
                      
                    <?php if($members->count()<1): ?>
                    <tr>
                        <td colspan="5" class="text-center"><b>No member is registered yet</b></td>
                    </tr>
                    <?php endif; ?>
                      <?php $__currentLoopData = $members; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $member): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                          <?php
                              $xDate = $member->subscription->exp_date;
                          ?>
                          <tr>
                              <td><?php echo e($member->name); ?></td>
                              <td><?php echo e($member->getCurrentPackageName()); ?></td>
                              <td><?php echo e($member->subscription->expireDate($xDate)); ?></td>
                              <td><?php echo e($member->subscription->remainingDays($xDate)); ?></td>
                              <td>
                                  <a href="<?php echo e(route('system_admin.member.show', $member)); ?>" class="btn btn-primary">View</a>
                              </td>
                          </tr>
                      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  </tbody>
                </table>
              </div>
          </div>
      </div>
  </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.backend.system_admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\ABDUL HALIM\Desktop\Portal\resources\views/system_admin/member/member_list.blade.php ENDPATH**/ ?>