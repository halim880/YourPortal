


<?php $__env->startSection('content'); ?>
    

<!-- NAVBAR START -->
<?php echo $__env->make('landing.partials._navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<!-- NAVBAR END -->

<!-- START HERO -->
<?php echo $__env->make('landing.partials._hero', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<!-- END HERO -->

<?php echo $__env->make('landing.partials._services', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<!-- END PRICING -->
<?php echo $__env->make('landing.partials._pricing', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>



<!-- START FAQ -->
<?php echo $__env->make('landing.partials._faqs', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<!-- END FAQ -->


<!-- START CONTACT -->
<?php echo $__env->make('landing.partials._contact', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('landing.partials._footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('new_layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\ABDUL HALIM\Desktop\Portal\resources\views/landing/landing_page.blade.php ENDPATH**/ ?>