<?php

namespace Tests\Unit\Bussiness;

use PHPUnit\Framework\TestCase;

class InvitationTest extends TestCase
{
    /**
     * A basic unit test example.
     *
     * @return void
     */
    public function test_example()
    {
        $this->assertTrue(true);
    }
}
