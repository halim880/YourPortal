 

<?php $__env->startSection('content'); ?>
  
  <div class="row mt-3">
    <div class="col-md-6">
      <div class="card">
        <div class="card-body">
          <?php if(Session::has('message')): ?>
          <div class="alert alert-warning">
            <p class=""><?php echo e(Session::get('message')); ?></p>
          </div>
          <?php endif; ?>
          <h3>Select user to assign the task</h3>
          <form action="<?php echo e(route('member.task.assign')); ?>" method="post">
            <?php echo csrf_field(); ?>
            <input type="text" name="task_id" value="<?php echo e($task_id); ?>" style="display: none">
            <input type="number" name="member_id" value="<?php echo e(Auth::user()->member()->id); ?>" style="display: none">
            <div class="form-group mb-3">
              <select name="user_id" id="member" class="form-control">
                <?php if($users->count()>0): ?>
                    <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($user->id); ?>"><?php echo e($user->name); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php endif; ?>
              </select>
            </div>
              <div class="d-flex my-2">
                  <button type="submit" class="btn btn-primary">Assign</button>
              </div>
          </form>
        </div>
      </div>
    </div>
  </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.backend._member', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\ABDUL HALIM\Desktop\Portal\resources\views/member/task/assign_form.blade.php ENDPATH**/ ?>