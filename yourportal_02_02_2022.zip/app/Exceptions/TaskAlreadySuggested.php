<?php

namespace App\Exceptions;

use Exception;

class TaskAlreadySuggested extends Exception
{

}
