<?php $__env->startComponent('mail::message'); ?>
# Helle, <?php echo e($name); ?>


We are very delighted that you are joining with us. We are proccessing your free membership. stay with us.

<?php $__env->startComponent('mail::button', ['url' => 'http://127.0.0.1:8000']); ?>
YourPortal
<?php echo $__env->renderComponent(); ?>

Thanks,<br>
<?php echo e(config('app.name')); ?>

<?php echo $__env->renderComponent(); ?>
<?php /**PATH C:\Users\ABDUL HALIM\Desktop\Portal\resources\views/mail/bussiness-application-received.blade.php ENDPATH**/ ?>