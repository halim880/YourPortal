
<?php $__env->startSection('content'); ?>
    <?php echo $__env->make('home_page._landing', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    
    


    <?php echo $__env->make('home_page._pricing_table', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>

<script> 
    
</script>

<style>

    .col-md-6{
        padding: 0 !important;
    }

    .img-responsive{
        height: 100%;
        width: 100%;
    }

    .feature-card{
        padding: 16px;
    }
    .slider{
        background: rgb(212, 220, 221);
    }


</style>
<?php echo $__env->make('layouts.frontend.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\ABDUL HALIM\Desktop\Portal\resources\views/home_page/home_page.blade.php ENDPATH**/ ?>