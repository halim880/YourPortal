
@extends('layouts.frontend.app')

@section('content')

@include('web.partials._navbar')
<!-- START CONTACT -->
@include('web.partials._contact')
<!-- END CONTACT -->
@include('web.partials._footer')

@endsection