 

<?php $__env->startSection('content'); ?>
  
  <div class="row mt-3">
    <div class="col-md-6">
      <div class="card">
        <div class="card-body">
          <?php if(Session::has('message')): ?>
          <div class="alert alert-warning">
            <p class=""><?php echo e(Session::get('message')); ?></p>
          </div>
          <?php endif; ?>
          <h3>Select Member to suggest the task</h3>
          <form action="<?php echo e(route('super_admin.task.suggest.send')); ?>" method="post">
            <?php echo csrf_field(); ?>
            <input type="text" name="task_id" value="<?php echo e($task_id); ?>" style="display: none">
            <div class="form-group mb-3">
              <select name="member_id" id="member" class="form-control">
                <?php $__currentLoopData = $members; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $member): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($member->id); ?>"><?php echo e($member->name); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              </select>
            </div>
              <div class="d-flex my-2">
                  <button type="submit" class="btn btn-primary">Send suggestion</button>
              </div>
          </form>
        </div>
      </div>
    </div>
  </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.backend.super_admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\ABDUL HALIM\Desktop\Portal\resources\views/super_admin/task/suggest.blade.php ENDPATH**/ ?>