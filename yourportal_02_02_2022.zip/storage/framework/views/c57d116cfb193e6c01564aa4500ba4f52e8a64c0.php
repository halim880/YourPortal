<section class="header-section" style="background-image: url(<?php echo e(asset('/images/landing-bg.jpg')); ?>)">
    <div class="container card">
        <div class="row">
            <div class="col-8">
                <div class="header-title">
                    <h1>Welcome to Your Portal</h1>
                    <h3>The Intelligent Club Client Portal.</h3>
                </div>
                <div class="details">
                    <p>Work smarter, Be more efficient, save time and money for you and your clients.

                        Be GDPR compliant, Be security conscious, Protect your clients privacy.
                        
                        Stay ahead of your competitors. You are in safe hands when it comes to data sharing.
                    </p>
                </div>
                <div class="buttons d-flex">
                    <a class="member-login-button" href="<?php echo e(route('bussiness.create')); ?>">Try 90 days for Free</a>
                </div>
            </div>
        </div>
        <div>

        </div>
    </div>
</section>

<style>
    .header-section{
        padding-top: 50px;
        padding-bottom: 50px;
        min-height: 80vh;
        background: rgb(253, 253, 253);
        font-family: 'Poppins', serif;
    }

    .header-section .container{
        /* background: rgb(243, 243, 243); */
        border: none;
    }

    .header-title h1{
        margin: 20px 0;
        font-weight: bold;
        font-size: 46;
        color: rgb(22, 100, 74);
        text-transform: uppercase;
    }

    .header-title h3{
        font-size: 30px !important;
    }

    .details{
        font-size: 20;
        font-weight: 500;
    }

    .header-section .member-login-button{
        background: rgb(248, 156, 35);
        color: rgb(14, 1, 1);
        padding: 13px;
        margin-top: 15px;
        text-transform: uppercase;
        transition: all 0.3s ease;
    }
    .header-section .member-login-button:hover{
        color: rgb(255, 255, 255);
    }
</style><?php /**PATH C:\Users\ABDUL HALIM\Desktop\Portal\resources\views/home_page/_landing.blade.php ENDPATH**/ ?>