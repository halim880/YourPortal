@extends('layouts.frontend.app')

@section('content')
    @include('web.partials._navbar')
    @include('web.partials._faqs')
    @include('web.partials._footer')
@endsection