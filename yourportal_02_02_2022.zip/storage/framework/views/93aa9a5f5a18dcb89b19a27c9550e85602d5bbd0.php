

<?php $__env->startSection('content'); ?>

  <?php if(Session::has('message')): ?>
    <?php echo $__env->make('alerts._success', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
  <?php endif; ?>
  
  <div class="row mt-2">
      <div class="col-md-10">
          <div class="card">
              <div class="card-body p-4">
                  <div class="d-flex justify-content-between">
                    <h4>Packages</h4>
                    <a class="btn btn-primary p-2" href="<?php echo e(route('system_admin.package.create')); ?>">Add New Package</a>
                </div>
                <table class="table">
                    <thead>
                        <th>Name</th>
                        <th>Admin limit</th>
                        <th>User limit</th>
                        <th>Action</th>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $packages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $package): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($package->name); ?></td>
                            <td><?php echo e($package->admin_limit); ?></td>
                            <td><?php echo e($package->user_limit); ?></td>
                            <td>
                                <a href="<?php echo e(route('system_admin.package.edit', $package)); ?>" class="btn btn-primary btn-sm mt-1">Edit</a>
                                <a href="<?php echo e(route('system_admin.package.destroy', $package)); ?>" class="btn btn-warning btn-sm mt-1">Delete</a>
                            </td>
                        </tr>                            
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
              </div>
          </div>
      </div>
  </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.backend.system_admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\ABDUL HALIM\Desktop\Portal\resources\views/system_admin/package/index.blade.php ENDPATH**/ ?>