<div class="alert alert-success">
    <p><?php echo e(Session::get('success')); ?></p>
</div><?php /**PATH C:\Users\ABDUL HALIM\Desktop\Portal\resources\views/alerts/success.blade.php ENDPATH**/ ?>