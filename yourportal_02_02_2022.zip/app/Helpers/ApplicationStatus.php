<?php
namespace App\Helpers;

class ApplicationStatus {
    const PENDING = 'pending';
    const PROCESSING = 'processing';
    const APROVED = 'approved';
    const REJECTED = 'rejected';
}