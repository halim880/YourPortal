<?php $__env->startComponent('mail::message'); ?>
# Congrats, <?php echo e($name); ?>


Now you are a part of YourPortal family,
Here is your login credentials, <br>
<b>email: <?php echo e($email); ?></b> <br>
<b>password: <?php echo e($password); ?></b> <br>
Please change the password as soon as possible

<?php $__env->startComponent('mail::button', ['url' => 'http://127.0.0.1:8000/login']); ?>
Login Here
<?php echo $__env->renderComponent(); ?>

Thanks,<br>
<?php echo e(config('app.name')); ?>

<?php echo $__env->renderComponent(); ?>
 <?php /**PATH C:\Users\ABDUL HALIM\Desktop\Portal\resources\views/mail/application-approved-mail.blade.php ENDPATH**/ ?>