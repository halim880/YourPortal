

<?php $__env->startSection('content'); ?>

  <?php if(Session::has('message')): ?>
    <?php echo $__env->make('alerts._success', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
  <?php endif; ?>
  
  <div class="row mt-2">
      <div class="col-md-6">
          <div class="card">
              <div class="card-body p-4">
                <h2>Create Package</h2>
                <form action="<?php echo e(route('system_admin.pricing.store')); ?>" method="post">
                    <?php echo csrf_field(); ?>
                    <div class="form-group mb-3">
                      <label for="package_id">Package</label>
                      <select name="package_id" id="package_id" class="form-control">
                        <?php $__currentLoopData = $packages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $package): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($package->id); ?>"><?php echo e($package->name); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                      </select>
                    </div>

                    <div class="form-group mb-3">
                      <label for="plan_id">Plan</label>
                      <select name="plan_id" id="plan_id" class="form-control">
                        <?php $__currentLoopData = $plans; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $plan): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($plan->id); ?>"><?php echo e($plan->name); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                      </select>
                    </div>

                    <div class="form-group mb-3">
                        <label for="price">Price</label>
                        <input type="number" class="form-control" id="price" name="price" required>
                      </div>

                      <div class="form-group mb-3">
                        <label for="currency_id">Currency</label>
                        <select name="currency_id" id="currency_id" class="form-control">
                          <?php $__currentLoopData = $currencies; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $currency): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                              <option value="<?php echo e($currency->id); ?>"><?php echo e($currency->name); ?></option>
                          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                      </div>

                    <div class="d-flex my-2">
                        <button type="submit" class="btn btn-primary">Save</button>
                    </div>
              </div>
          </div>
      </div>
  </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.backend.system_admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\ABDUL HALIM\Desktop\Portal\resources\views/system_admin/pricing/create.blade.php ENDPATH**/ ?>