<?php

namespace Database\Factories\Company;

use Illuminate\Database\Eloquent\Factories\Factory;

class CompanyApplicationFactory extends Factory
{
    /**
     * Define the model's default state.
     *
     * @return array
     */
    public function definition()
    {
        return [
            //
        ];
    }
}
