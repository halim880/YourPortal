<?php echo e($slot); ?>

<?php /**PATH C:\Users\ABDUL HALIM\Desktop\Portal\vendor\laravel\framework\src\Illuminate\Mail/resources/views/text/footer.blade.php ENDPATH**/ ?>