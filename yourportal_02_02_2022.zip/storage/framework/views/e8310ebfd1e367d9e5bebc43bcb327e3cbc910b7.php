


<?php $__env->startSection('content'); ?>

<!-- END wrapper -->
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.backend._member', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\ABDUL HALIM\Desktop\Portal\resources\views/member/dashboard.blade.php ENDPATH**/ ?>