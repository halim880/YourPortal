


<?php $__env->startSection('content'); ?>

<!-- END wrapper -->
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.backend', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\ABDUL HALIM\Desktop\Portal\resources\views/admin/dashboard.blade.php ENDPATH**/ ?>