;

<?php echo $__env->make('layouts.backend.super_admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\ABDUL HALIM\Desktop\Portal\resources\views/super_admin/dashboard.blade.php ENDPATH**/ ?>