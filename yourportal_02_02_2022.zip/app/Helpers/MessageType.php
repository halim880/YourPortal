<?php
namespace App\Helpers;

class MessageType {
    const TEXT = "text";
    const IMAGE = "image";
    const FILE =  "file";
}