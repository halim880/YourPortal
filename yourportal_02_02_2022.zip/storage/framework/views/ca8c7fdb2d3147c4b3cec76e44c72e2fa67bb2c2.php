

<?php $__env->startSection('content'); ?>
  
  <div class="row mt-2">
      <div class="col-md-10">
          <div class="card">
              <div class="card-body p-4">
                <h2>List of Tasks</h2>
                <table class="table">
                  <thead>
                      <th>Title</th>
                      
                      <th>Actions</th>
                  </thead>
                  <tbody>
                      
                    <?php if($tasks->count()<1): ?>
                    <tr>
                        <td colspan="3" class="text-center"><b>No Assigned Tasks</b></td>
                    </tr>
                    <?php endif; ?>
                  
                      <?php $__currentLoopData = $tasks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $task): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                          <tr>
                              <td><?php echo e($task->title); ?></td>
                              
                              <td>
                                  <a href="" class="btn btn-primary">View</a>
                              </td>
                          </tr>
                      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  </tbody>
                </table>
              </div>
          </div>
      </div>
  </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.backend._member', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\ABDUL HALIM\Desktop\Portal\resources\views/member/user/task/assigned.blade.php ENDPATH**/ ?>