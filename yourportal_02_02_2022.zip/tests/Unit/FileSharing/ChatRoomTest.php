<?php

namespace Tests\Unit\FileSharing;

use Illuminate\Foundation\Testing\DatabaseMigrations;
use Tests\TestCase;

class ChatRoomTest extends TestCase
{
    use DatabaseMigrations;

    public function test_folder_can_be_created(){
        $data = [
            'name'=> "",
        ];

        
    }
}
