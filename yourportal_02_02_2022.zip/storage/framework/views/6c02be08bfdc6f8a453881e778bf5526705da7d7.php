


<?php $__env->startSection('content'); ?>

<div class="row mt-3">
  <div class="col-md-6">
    <div class="card">
      <div class="card-header">
        <h3>Invitation</h3>
      </div>
      <div class="card-body p-3">
          <?php if(Session::has('message')): ?>
            <div class="alert alert-success">
              <p>
                <?php echo e(Session::get('message')); ?>

              </p>
            </div>
            <?php endif; ?>
          <form action="<?php echo e(route('member.send.invitation')); ?>" method="post">
            <?php echo csrf_field(); ?>
            <div class="form-group mb-3">
              <label for="email">Email </label>
              <input type="email" class="form-control" id="email" name="email" required>
            </div>
              <div class="d-flex my-2">
                  <button type="submit" class="btn btn-primary">Send invitation</button>
              </div>
          </form>
        </div>
      </div>
    </div>
  </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.backend._member', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\ABDUL HALIM\Desktop\Portal\resources\views/member/invite_user.blade.php ENDPATH**/ ?>