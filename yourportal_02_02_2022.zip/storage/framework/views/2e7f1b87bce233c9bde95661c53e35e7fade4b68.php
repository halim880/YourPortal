

<?php $__env->startSection('content'); ?>
<div class="row mt-3">
    <div class="col-md-12">
        <div class="card">
            <div class="card-body p-3">
                <h3>Member's Requests</h3>
                <table id="datatable-buttons" class="table table-striped dt-responsive">
                    <thead>
                        <tr>
                            <th>Member name</th>
                            
                            <th>Admin Name</th>
                            <th>Package</th>
                            <th>Actions</th>
                        </tr>
                    </thead>
                
                
                    <tbody>
                        <?php if($applications->count()<1): ?>
                            <tr>
                                <td colspan="5" style="text-align: center">No Member Request</td>
                            </tr>
                        <?php else: ?>
                            <?php $__currentLoopData = $applications; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $application): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($application->name); ?></td>
                                
                                <td><?php echo e($application->admin_name); ?></td>
                                <td><?php echo e($application->getPackageName()); ?></td>
                                <?php if($application->status=='approved'): ?>
                                    <td>
                                        <button disabled class="btn btn-secondary">Approved</button>
                                    </td>
                                <?php elseif($application->status=='rejected'): ?>
                                    <td>
                                        <button disabled class="btn btn-warning">Rejected</button>
                                    </td>
                                <?php else: ?>
                                    <td>
                                        <a href="<?php echo e(route('system_admin.member_application.approve', $application)); ?>" class="btn btn-sm btn-success">Approve</a>
                                        <a href="<?php echo e(route('system_admin.member_application.reject', $application)); ?>" class="btn btn-sm btn-danger">Reject</a>
                                    </td>
                                <?php endif; ?>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php endif; ?>
                    </tbody>
                </table>  
            </div>
        </div>
    </div>
</div> 
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.backend.system_admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\ABDUL HALIM\Desktop\Portal\resources\views/system_admin/member_application/application_list.blade.php ENDPATH**/ ?>