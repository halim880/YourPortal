

<?php $__env->startSection('content'); ?>

  <?php if(Session::has('message')): ?>
    <?php echo $__env->make('alerts._success', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
  <?php endif; ?>
  
  <div class="row mt-2">
      <div class="col-md-10">
          <div class="card">
              <div class="card-body p-4">
                <h2>Create Package</h2>
                <form action="<?php echo e(route('system_admin.package.store')); ?>" method="post">
                    <?php echo csrf_field(); ?>
                    <div class="form-group mb-3">
                      <label for="package_name">Package Name</label>
                      <input type="text" class="form-control" id="package_name" name="package_name" required>
                    </div>

                    <div class="form-group mb-3">
                        <label for="admin_limit">Admin limit</label>
                        <input type="number" class="form-control" id="admin_limit" name="admin_limit" required>
                      </div>

                      <div class="form-group mb-3">
                        <label for="user_limit">User limit</label>
                        <input type="number" class="form-control" id="user_limit" name="user_limit" required>
                      </div>

                    <div class="d-flex my-2">
                        <button type="submit" class="btn btn-primary">Save</button>
                    </div>
              </div>
          </div>
      </div>
  </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.backend.system_admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\ABDUL HALIM\Desktop\Portal\resources\views/system_admin/package/create.blade.php ENDPATH**/ ?>