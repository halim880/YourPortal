<?php $__env->startComponent('mail::message'); ?>
# Hey !,
You are invited to join <b><?php echo e($member_name); ?></b>

<?php $__env->startComponent('mail::button', ['url' => $url]); ?>
Join Now
<?php echo $__env->renderComponent(); ?>

Thanks,<br>
<?php echo e(config('app.name')); ?>

<?php echo $__env->renderComponent(); ?>
<?php /**PATH C:\Users\ABDUL HALIM\Desktop\Portal\resources\views/mail/member-invitation.blade.php ENDPATH**/ ?>