

<?php $__env->startSection('content'); ?>

  <?php if(Session::has('message')): ?>
    <?php echo $__env->make('alerts._success', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
  <?php endif; ?>
  
  <div class="row mt-2">
      <div class="col-md-10">
          <div class="card">
              <div class="card-body p-4">
                  <div class="d-flex justify-content-between">
                    <h4>plans</h4>
                    <a class="btn btn-primary p-2" href="<?php echo e(route('system_admin.plan.create')); ?>">Add New plan</a>
                </div>
                <table class="table">
                    <thead>
                        <th>ID</th>
                        <th>Name</th>
                        <th>Duration</th>
                        <th>Action</th>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $plans; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $plan): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($plan->id); ?></td>
                            <td><?php echo e($plan->name); ?></td>
                            <td><?php echo e($plan->duration); ?></td>
                            <td>
                                <a href="<?php echo e(route('system_admin.plan.edit', $plan)); ?>" class="btn btn-primary btn-sm mt-1">Edit</a>
                                <a href="<?php echo e(route('system_admin.plan.destroy', $plan)); ?>" class="btn btn-warning btn-sm mt-1">Delete</a>
                            </td>
                        </tr>                            
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
              </div>
          </div>
      </div>
  </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.backend.system_admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\ABDUL HALIM\Desktop\Portal\resources\views/system_admin/plan/index.blade.php ENDPATH**/ ?>