

<?php $__env->startSection('content'); ?>
<div class="row mt-3">
    <div class="col-md-12">
        <div class="card">
            <div class="card-body p-3">
                <h3>Member's Requests</h3>
                <table id="datatable-buttons" class="table table-striped dt-responsive nowrap w-100">
                    <thead>
                        <tr>
                            <th>Bussiness name</th>
                            <th>Email</th>
                            <th>Phone</th>
                            <th>Admin</th>
                            <th>Admmin email</th>
                            <th>Actions</th>
                        </tr>
                    </thead>
                
                
                    <tbody>
                        <?php $__currentLoopData = $applications; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $application): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($application->name); ?></td>
                            <td><?php echo e($application->bussiness_email); ?></td>
                            <td><?php echo e($application->bussiness_phone); ?></td>
                            <td><?php echo e($application->admin_name); ?></td>
                            <td><?php echo e($application->admin_email); ?></td>
                            <?php if($application->status=='approved'): ?>
                                <td>
                                    <button disabled class="btn btn-secondary">Approved</button>
                                </td>
                            <?php elseif($application->status=='rejected'): ?>
                            <td>
                                <button disabled class="btn btn-warning">Rejected</button>
                            </td>
                            <?php else: ?>
                            <td>
                                <a href="<?php echo e(route('bussiness_application.approve', $application)); ?>" class="btn btn-sm btn-success">Approve</a>
                                <a href="<?php echo e(route('bussiness.application.reject', $application)); ?>" class="btn btn-sm btn-danger">Reject</a>
                            </td>
                            <?php endif; ?>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>  
            </div>
        </div>
    </div>
</div> 
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.backend.super_admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\ABDUL HALIM\Desktop\Portal\resources\views/super_admin/member_application/application_list.blade.php ENDPATH**/ ?>